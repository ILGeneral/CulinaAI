// @ts-ignore
/// <reference types="nativewind/types" />
